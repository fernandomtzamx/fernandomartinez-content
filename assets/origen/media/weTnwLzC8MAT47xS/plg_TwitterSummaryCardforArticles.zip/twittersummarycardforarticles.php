<?php
/**
 * @package    TwitterSummaryCardforArticles
 * @subpackage Base
 * @author     Fernando Martinez {@link https://www.fernandomartinez.mx/}
 * @author     Created on 13-Jan-2016
 * @license    GNU/GPL
 */

//-- No direct access
defined('_JEXEC') || die('=;)');


jimport('joomla.plugin.plugin');

/**
 * Content Plugin.
 *
 * @package    TwitterSummaryCardforArticles
 * @subpackage Plugin
 */
class plgContentTwitterSummaryCardforArticles extends JPlugin
{
    public function onContentPrepare($context, &$article, &$params, $limitstart)
    {
		if ($context == "com_content.article") {
			$article_images = $article->images;
			$pictures = json_decode($article_images);

			$twImage = $pictures->{'image_intro'};
			$twSite= $this->params->get('twittersite');
			$twCreator= $this->params->get('twittercreator');
			$twTitle= $article->title;
			$twDescription= $article->metadesc;

			$document = JFactory::getDocument();
			$document->addCustomTag('<meta name="twitter:card" content="summary" />');

			$document->addCustomTag('<meta name="twitter:site" content="'.$twSite.'" />');
			$document->addCustomTag('<meta name="twitter:creator" content="'.$twCreator.'" />');
			$document->addCustomTag('<meta name="twitter:title" content="'.$twTitle.'" />');
			$document->addCustomTag('<meta name="twitter:description" content="'.$twDescription.'" />');
			$document->addCustomTag('<meta name="twitter:image" content="'.JURI::root() . $twImage.'" />'); 
		} else {
			return;
		}
    }//function
}//class